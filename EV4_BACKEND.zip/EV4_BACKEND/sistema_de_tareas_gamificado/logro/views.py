from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView
from django.urls import reverse_lazy
from .models import Logro
from .forms import LogroForm

# Vista para listar logros
class LogroListView(ListView):
    model = Logro
    template_name = 'logro/lista_logros.html'
    context_object_name = 'logros'

# Vista para crear un logro
class LogroCreateView(CreateView):
    model = Logro
    form_class = LogroForm
    template_name = 'logro/crear_logro.html'
    success_url = reverse_lazy('lista_logros')

# Vista para editar un logro
class LogroUpdateView(UpdateView):
    model = Logro
    form_class = LogroForm
    template_name = 'logro/editar_logro.html'
    success_url = reverse_lazy('lista_logros')

# Vista para eliminar un logro
class LogroDeleteView(DeleteView):
    model = Logro
    template_name = 'logro/eliminar_logro.html'
    success_url = reverse_lazy('lista_logros')

# Vista para ver detalles de un logro
class LogroDetailView(DetailView):  # Nueva vista agregada
    model = Logro
    template_name = 'logro/detalle_logro.html'
    context_object_name = 'logro'
