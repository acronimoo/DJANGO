from django.urls import path
from .views import (
    LogroListView,
    LogroCreateView,
    LogroUpdateView,
    LogroDeleteView,
    LogroDetailView,  # Importa la nueva vista
)

urlpatterns = [
    path('', LogroListView.as_view(), name='lista_logros'),
    path('crear/', LogroCreateView.as_view(), name='crear_logro'),
    path('<int:pk>/editar/', LogroUpdateView.as_view(), name='editar_logro'),
    path('<int:pk>/eliminar/', LogroDeleteView.as_view(), name='eliminar_logro'),
    path('<int:pk>/', LogroDetailView.as_view(), name='detalle_logro'),  # Nueva ruta agregada
]
