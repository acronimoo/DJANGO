from django import forms
from .models import Logro

class LogroForm(forms.ModelForm):
    class Meta:
        model = Logro
        fields = ['usuario', 'nombre_del_logro', 'descripcion']

    # Validación personalizada para nombre del logro
    def clean_nombre_del_logro(self):
        nombre = self.cleaned_data['nombre_del_logro']
        if len(nombre) < 3:
            raise forms.ValidationError("El nombre del logro debe tener al menos 3 caracteres.")
        return nombre
