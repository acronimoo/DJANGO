from django.db import models

# Create your models here.
from usuario.models import Usuario

class Logro(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='logros')
    nombre_del_logro = models.CharField(max_length=255)
    descripcion = models.TextField()

    def __str__(self):
        return self.nombre_del_logro