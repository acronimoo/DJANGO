from django.contrib import admin
from django.urls import path, include
from .views import home, tablero_progreso
from usuario.views import login_view, logout_view  # Importa las vistas para login y logout
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('', home, name='home'),  # Página principal
    path('admin/', admin.site.urls),
    path('tareas/', include('tarea.urls')),
    path('logros/', include('logro.urls')),
    path('usuarios/', include('usuario.urls')),  # Gestión de usuarios
    path('tablero/', tablero_progreso, name='tablero_progreso'),
    path('login/', login_view, name='login'),  # Ruta para inicio de sesión
    path('logout/', logout_view, name='logout'),  # Ruta para cierre de sesión
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # URL para obtener tokens
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # URL para refrescar tokens
]
