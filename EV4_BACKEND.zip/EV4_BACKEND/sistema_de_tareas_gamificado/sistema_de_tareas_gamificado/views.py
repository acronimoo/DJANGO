from django.shortcuts import render, redirect
from tarea.models import Tarea
from logro.models import Logro
from django.db.models import Sum
from django.contrib.auth.decorators import login_required
@login_required
def home(request):
    return render(request,'home.html')


def tablero_progreso(request):
    # Calcular el progreso de tareas
    total_tareas = Tarea.objects.count()
    tareas_completadas = Tarea.objects.filter(estado='completada').count()
    tareas_pendientes = total_tareas - tareas_completadas

    # Calcular puntos acumulados de tareas completadas
    puntos_acumulados = Tarea.objects.filter(estado='completada').aggregate(total_puntos=Sum('puntos'))['total_puntos'] or 0

    # Contar logros alcanzados
    total_logros = Logro.objects.count()

    # Pasar los datos al template
    contexto = {
        'total_tareas': total_tareas,
        'tareas_completadas': tareas_completadas,
        'tareas_pendientes': tareas_pendientes,
        'puntos_acumulados': puntos_acumulados,
        'total_logros': total_logros,
    }
    return render(request, 'tablero_progreso.html', contexto)
