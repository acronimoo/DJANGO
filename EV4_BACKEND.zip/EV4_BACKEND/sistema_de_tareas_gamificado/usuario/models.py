from django.db import models

# Create your models here.
class Usuario(models.Model):
    nombre = models.CharField(max_length=255)
    correo = models.EmailField(unique=True)
    nivel = models.PositiveIntegerField(default=1)

    def __str__(self):
        return self.nombre