from django import forms
from .models import Usuario

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['nombre', 'correo', 'nivel']

    # Validación personalizada para el campo 'nivel'
    def clean_nivel(self):
        nivel = self.cleaned_data['nivel']
        if nivel < 1:
            raise forms.ValidationError("El nivel debe ser mayor o igual a 1.")
        return nivel
