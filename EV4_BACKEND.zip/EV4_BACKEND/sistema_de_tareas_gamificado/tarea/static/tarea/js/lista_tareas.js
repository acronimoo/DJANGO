document.getElementById('btnFiltrar').addEventListener('click', cargarTareas);

console.log(localStorage.getItem('access_token'));
async function cargarTareas() {
    const usuario = document.getElementById("usuarioID").value || "";
    const estado = document.getElementById("estadoFiltro").value || "";
    const url = `/tareas/api/tareas/?usuario=${usuario}&estado=${estado}`;
    const token = localStorage.getItem('access_token');

    try {
        if (!token) {
            alert("No estás autenticado. Inicia sesión primero.");
            return;
        }

        const response = await fetch(url, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`, // Aquí se envía el token
                "Content-Type": "application/json",
            },
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }

        const data = await response.json();
        console.log("Tareas cargadas:", data);

        // Renderizar las tareas en la interfaz
        const contenedorTareas = document.getElementById("contenedor-tareas");
        contenedorTareas.innerHTML = "";
        data.results.forEach((tarea) => {
            const tareaElemento = document.createElement("div");
            tareaElemento.innerHTML = `
                <h3>${tarea.titulo}</h3>
                <p>${tarea.descripcion}</p>
                <p>Estado: ${tarea.estado}</p>
                <p>Puntos: ${tarea.puntos}</p>
            `;
            contenedorTareas.appendChild(tareaElemento);
        });
    } catch (error) {
        console.error("Error al obtener las tareas:", error);
        alert("Hubo un problema al cargar las tareas. Verifica tu autenticación.");
    }
}

document.getElementById("btnFiltrar").addEventListener("click", cargarTareas);


async function refrescarToken() {
    const refreshToken = localStorage.getItem('refresh_token'); // Asegúrate de guardar también el refresh token
    const response = await fetch('/api/token/refresh/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh: refreshToken }),
    });

    if (response.ok) {
        const data = await response.json();
        localStorage.setItem('access_token', data.access);
    } else {
        console.error("No se pudo refrescar el token.");
    }
}


