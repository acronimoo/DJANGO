from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from django.urls import reverse_lazy
from .models import Tarea
from .forms import TareaForm
from .serializers import TareaSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import NotFound

# Vista para listar tareas en el frontend
class TareaListView(ListView):
    model = Tarea
    template_name = 'tarea/lista_tareas.html'
    context_object_name = 'tareas'

# Vista para crear una nueva tarea
class TareaCreateView(CreateView):
    model = Tarea
    form_class = TareaForm
    template_name = 'tarea/crear_tarea.html'
    success_url = reverse_lazy('lista_tareas')

# Vista para actualizar una tarea
class TareaUpdateView(UpdateView):
    model = Tarea
    form_class = TareaForm
    template_name = 'tarea/editar_tarea.html'
    success_url = reverse_lazy('lista_tareas')

# Vista para eliminar una tarea
class TareaDeleteView(DeleteView):
    model = Tarea
    template_name = 'tarea/eliminar_tarea.html'
    success_url = reverse_lazy('lista_tareas')

# API para listar tareas filtradas por usuario o estado


class TareaFilteredListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        usuario_id = request.query_params.get('usuario', None)
        estado = request.query_params.get('estado', None)

        tareas = Tarea.objects.all()
        if usuario_id:
            tareas = tareas.filter(usuario_id=usuario_id)
        if estado:
            tareas = tareas.filter(estado=estado)

        paginator = PageNumberPagination()
        paginated_tareas = paginator.paginate_queryset(tareas, request)
        serializer = TareaSerializer(paginated_tareas, many=True)
        return paginator.get_paginated_response(serializer.data)
