from django.urls import path
from .views import (
    TareaListView,
    TareaCreateView,
    TareaUpdateView,
    TareaDeleteView,
    TareaFilteredListView,
)

urlpatterns = [
    path('', TareaListView.as_view(), name='lista_tareas'),  # Listar tareas
    path('crear/', TareaCreateView.as_view(), name='crear_tarea'),  # Crear tarea
    path('<int:pk>/editar/', TareaUpdateView.as_view(), name='editar_tarea'),  # Editar tarea
    path('<int:pk>/eliminar/', TareaDeleteView.as_view(), name='eliminar_tarea'),  # Eliminar tarea
    path('api/tareas/', TareaFilteredListView.as_view(), name='api_tareas_filtradas'),
]
