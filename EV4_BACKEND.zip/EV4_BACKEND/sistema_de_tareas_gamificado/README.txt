GESTOR DE TAREAS GAMIFICADO

Descripción:
El Gestor de Tareas Gamificado es una aplicación web diseñada para ayudar a los usuarios a organizar sus tareas diarias de forma divertida y eficiente. Los usuarios pueden gestionar tareas, ganar puntos al completarlas y obtener logros en función de su progreso.

Características:
- Gestión de Tareas:
  - Crear, editar y eliminar tareas.
  - Filtrar tareas por usuario y estado.
  - Estados disponibles: pendiente, completada.
- Sistema de Logros:
  - Obtención de logros según el progreso del usuario.
- Autenticación:
  - Inicio de sesión con JWT.
  - Tokens de acceso y refresco.
- Tablero de Progreso:
  - Visualización de tareas completadas, puntos acumulados y logros.
- API RESTful:
  - CRUD completo para tareas y logros.
  - Endpoints protegidos con autenticación.

Requisitos Previos:
- Python 3.8 o superior.
- Pipenv o virtualenv (opcional para entornos virtuales).
- Navegador web moderno.
- Postman o cURL para probar la API (opcional).

Instrucciones de Instalación:
1. Clona el repositorio del proyecto:
   git clone https://github.com/usuario/proyecto-tareas.git
   cd proyecto-tareas

2. Crea un entorno virtual y actívalo:
   - Linux/MacOS:
     python -m venv venv
     source venv/bin/activate
   - Windows:
     python -m venv venv
     venv\Scripts\activate

3. Instala las dependencias necesarias:
   pip install -r requirements.txt

4. Aplica las migraciones de la base de datos:
   python manage.py makemigrations
   python manage.py migrate

5. Crea un superusuario para acceder al administrador:
   python manage.py createsuperuser

6. Inicia el servidor:
   python manage.py runserver

7. Abre tu navegador y visita:
   http://127.0.0.1:8000/

Uso de la API:
- Endpoint para obtener un token:
  POST /api/token/
  Body:
  {
    "username": "tu_usuario",
    "password": "tu_contraseña"
  }

- Endpoint para refrescar el token:
  POST /api/token/refresh/
  Body:
  {
    "refresh": "TOKEN_DE_REFRESH"
  }

- Endpoint para listar tareas:
  GET /api/tareas/?usuario=<usuario_id>&estado=<estado>
  Headers:
  Authorization: Bearer <ACCESS_TOKEN>

Notas Adicionales:
- Recuerda usar un navegador moderno para garantizar la compatibilidad con la interfaz web.
- Utiliza Postman o herramientas similares para probar los endpoints de la API.

Licencia:
Este proyecto está bajo la Licencia MIT. Puedes usarlo, modificarlo y distribuirlo libremente bajo los términos de esta licencia.

Soporte:
Si tienes preguntas o encuentras errores, por favor contacta con el administrador del proyecto.
